# KasKu Majelis — Android

Project Android Studio untuk membungkus aplikasi KasKu Majelis ke dalam aplikasi Android offline.

## Yang sudah disiapkan
- Tampilan KasKu Majelis Biru Awan.
- WebView memuat halaman dari aset lokal, jadi halaman utama tidak membutuhkan internet.
- Penyimpanan transaksi memakai localStorage WebView pada perangkat.
- Ekspor CSV diarahkan ke penyimpanan Android melalui pemilih lokasi simpan.
- Ikon aplikasi sementara memakai ikon launcher default Android; ikon awan khusus bisa ditambahkan pada tahap berikutnya.

## Cara membuat APK
1. Instal/buka Android Studio pada komputer.
2. Pilih **Open** lalu pilih folder `KasKuMajelis_Android`.
3. Tunggu Gradle Sync selesai (koneksi internet mungkin diperlukan pertama kali untuk mengunduh komponen build).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Setelah selesai, Android Studio menampilkan lokasi APK. Pindahkan APK ke tablet Samsung dan instal.

## Catatan
Ini adalah source project Android Studio, belum berupa APK yang sudah dikompilasi. Kompilasi APK memerlukan Android SDK dan Gradle/Android build tools.
